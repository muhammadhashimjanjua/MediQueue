package mediqueue.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import mediqueue.auth.AuthService.Role;

/** Placeholder home screen shown after a successful login. */
public class DashboardFrame extends JFrame {

    public DashboardFrame(String fullName, Role role) {
        super("MediQueue - " + role);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel msg = new JLabel("<html><div style='text-align:center'><h1>Welcome, " + fullName
                + "</h1>Logged in as <b>" + role + "</b></div></html>", SwingConstants.CENTER);

        JButton logout = new JButton("Log Out");
        logout.addActionListener(new ActionListener() {
            @Override public void actionPerformed(ActionEvent e) {
                new LoginFrame().setVisible(true);
                dispose();
            }
        });
        JPanel south = new JPanel();
        south.add(logout);

        add(msg, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);
        setSize(520, 320);
        setLocationRelativeTo(null);
    }
}
