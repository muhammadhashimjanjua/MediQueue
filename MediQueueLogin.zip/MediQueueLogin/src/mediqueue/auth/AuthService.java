package mediqueue.auth;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Simple in-memory authentication for the lab demo.
 * Replace with a database / REST call in the full MediQueue project.
 */
public class AuthService {

    public enum Role { PATIENT, RECEPTIONIST, DOCTOR, ADMINISTRATOR;
        @Override public String toString() {
            String s = name().toLowerCase();
            return Character.toUpperCase(s.charAt(0)) + s.substring(1);
        }
    }

    private static class Account {
        final String password; final Role role; final String fullName;
        Account(String password, Role role, String fullName) {
            this.password = password; this.role = role; this.fullName = fullName;
        }
    }

    private final Map<String, Account> accounts = new LinkedHashMap<String, Account>();

    public AuthService() {
        accounts.put("patient",      new Account("patient123", Role.PATIENT,       "Ali Khan"));
        accounts.put("reception",    new Account("recep123",   Role.RECEPTIONIST,  "Sara Ahmed"));
        accounts.put("doctor",       new Account("doctor123",  Role.DOCTOR,        "Dr. Hamza Malik"));
        accounts.put("admin",        new Account("admin123",   Role.ADMINISTRATOR, "System Admin"));
    }

    /** @return the user's full name on success, or null if credentials/role are wrong. */
    public String login(String username, char[] password, Role role) {
        Account a = accounts.get(username == null ? "" : username.trim().toLowerCase());
        if (a == null || a.role != role) return null;
        return a.password.equals(new String(password)) ? a.fullName : null;
    }
}
